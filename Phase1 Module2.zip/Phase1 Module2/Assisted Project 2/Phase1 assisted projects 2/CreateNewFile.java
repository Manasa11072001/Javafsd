package Phase1Module2;
import java.io.File;
import java.io.IOException;
public class CreateNewFile {
	public static void main(String[] args)  {
        File myFile=new File("input3");
        
	 try {
		if(myFile.createNewFile())
		 {
			 System.out.println("file created");
			 
		 }
		 else {
			 System.out.println("file creation error");
		 }
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}


