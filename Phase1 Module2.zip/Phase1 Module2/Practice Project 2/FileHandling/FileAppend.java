package FileHandling;

import java.io.File;

import java.io.FileWriter;

public class FileAppend {
	public static void main(String[] args) {
		String data="Java is Superb";
		try	
		{
			FileWriter output=new FileWriter("input2",true);
			output.write(data);
			System.out.println("Data appended successfully");
			output.close();
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println("file append error...");
		}
		
	}

}
