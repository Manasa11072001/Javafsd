package FileHandling;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class Read {
	public static void main(String[] args) throws IOException {
		FileInputStream fi=null;
		
		try {
			fi=new FileInputStream("input2");
			//use true when we want to insert a new data on existing data in a file
			//fo=new FileOutputStream("input",true);
			if(fi!=null) {
				System.out.println("file existing to read...");
			}
			int i=0;             
			while((i=fi.read())!=-1) {
				System.out.print((char)i);
			}
			
		} 
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		finally {
			fi.close();
		}
	}
}
