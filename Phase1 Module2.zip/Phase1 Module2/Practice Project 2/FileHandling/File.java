package FileHandling;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class File {
	public static void main(String[] args) throws IOException {
		FileOutputStream fo=null;
		Scanner sc=null;
		try {
			fo=new FileOutputStream("input2");
			//use true when we want to insert a new data on existing data in a file
			//fo=new FileOutputStream("input",true);
			if(fo!=null) {
				System.out.println("file created and existing ...");
			}
			
			sc=new Scanner(System.in);
			System.out.println("enter input for a file");
			String fileinput=sc.nextLine();
			//convert the char to bytes 
			byte[] b=fileinput.getBytes();
			fo.write(b);
			System.out.println("data got inserted into the file ..");
		} 
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		finally {
			fo.close();
			sc.close();
		}
	}

}
