package Phase1;

public abstract class AnonymousInnerClass {
	//anonymous inner class
	   public abstract void display();

}
